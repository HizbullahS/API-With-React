import { useEffect, useState } from 'react';
import './style.css';

export default function Products() {

  const [users, setUsers] = useState([])

  const fetchData = () => {
    fetch("http://localhost:1020/api/Employee")
      .then(response => { return response.json() })
      .then(data => { setUsers(data) })
  }

  useEffect(() => {
    fetchData()
  }, []);


  return (
    <>
      <h1>Employee Data</h1>
      <div className="table-container">
        <div className='inner-table-container'>
          <table className="product-table">
            <thead>
              <tr>
                <th>Employee Id</th>
                <th>Employee Name</th>
                <th>CNIC</th>
                <th>Address</th>
                <th>Phone Number</th>
              </tr>
            </thead>
            <tbody>
              {users.map((user, index) => (
                <tr key={index}>
                  <td>{user.id}</td>
                  <td>{user.employeeName}</td>
                  <td>{user.cnic}</td>
                  <td>{user.address}</td>
                  <td>{user.phoneNo}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

      </div>
    </>
  );
}



